package com.ashok.learning.Topic;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/*  first  getter and setter 
 * After constructor using field
 * After superclass
 */

@Entity
public class Topic {
	
	@Id
	private String id;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescriptrion() {
		return Descriptrion;
	}

	public void setDescriptrion(String descriptrion) {
		Descriptrion = descriptrion;
	}

	private String name;
	private String Descriptrion;
	
	public Topic() {
	}

	public Topic(String id, String name, String descriptrion) {
		super();
		this.id = id;
		this.name = name;
		Descriptrion = descriptrion;
	}
}


