
	/*
	 * public List<Topic> getAllTopics(): Returns the list of all topics. public
	 * Topic getTopic(String id): Retrieves a specific Topic object based on the
	 * provided id. Uses a stream to filter the topics list based on the id. Uses
	 * findFirst() to get the first Topic that matches the id. Uses orElse(null) to
	 * return null if no Topic is found with the given id. public void
	 * addTopic(Topic topic): Adds a new Topic object to the topics list. public
	 * void updateTopic(String id, Topic updatedTopic): Updates an existing Topic
	 * object in the topics list based on the id. Iterates through the topics list
	 * to find the Topic with the matching id. Sets the updated Topic using
	 * topics.set(i, updatedTopic) if found.
	 */

	package com.ashok.learning.Topic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TopicService {

    @Autowired
    private TopicRepository topicRepository;

    public List<Topic> getAllTopics() {
        return topicRepository.findAll();
    }

    public Topic getTopic(String id) {
        Optional<Topic> topic = topicRepository.findById(id);
        return topic.orElse(null); // Returns null if topic is not found
    }

    public void addTopic(Topic topic) {
        topicRepository.save(topic);
    }

    public void updateTopic(String id, Topic updatedTopic) {
        // Check if the topic exists
        Optional<Topic> existingTopicOptional = topicRepository.findById(id);
        if (existingTopicOptional.isPresent()) {
            // Update the existing topic with new values
            Topic existingTopic = existingTopicOptional.get();
            existingTopic.setName(updatedTopic.getName());
            existingTopic.setDescriptrion(updatedTopic.getDescriptrion());
            // Save the updated topic
            topicRepository.save(existingTopic);
        } else {
            // Handle if the topic with given id does not exist
            throw new IllegalArgumentException("Topic with id " + id + " not found");
        }
    }

    public void deleteTopic(String id) {
        topicRepository.deleteById(id);
    }
}
